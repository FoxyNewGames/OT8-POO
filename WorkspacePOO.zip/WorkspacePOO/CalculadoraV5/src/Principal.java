import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int continuar;
		double resultado = 0;
		do {
			double num1 = EntradaSa�da.solicitaNumero("1�");
			double num2 = EntradaSa�da.solicitaNumero("2�");
			int operacao = EntradaSa�da.solicitaOperacao();

			switch (operacao) {
			case 1:
				Soma soma = new Soma();
				soma.setNum1(num1);
				soma.setNum2(num2);
				resultado = soma.calcula();
				break;
			case 2:
				Subtra��o sub = new Subtra��o();
				sub.setNum1(num1);
				sub.setNum2(num2);
				resultado = sub.calcula();
				break;
			case 3:
				Multiplica��o multi = new Multiplica��o();
				multi.setNum1(num1);
				multi.setNum2(num2);
				resultado = multi.calcula();
				break;
			case 4:
				while (num2 == 0) {
					num2 = EntradaSa�da.solicitaNumero("2�");
				}
				Divis�o divi = new Divis�o();
				divi.setNum1(num1);
				divi.setNum2(num2);
				resultado = divi.calcula();
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opera��o inv�lida! A calculadora ser� encerrada!");
				System.exit(0);
			}
			EntradaSa�da.mostraResultado(resultado, operacao);
			continuar = Integer.parseInt(JOptionPane.showInputDialog("Deseja continuar calculando? 1-Sim | 2-N�o"));

		} while (continuar == 1);
	}
}