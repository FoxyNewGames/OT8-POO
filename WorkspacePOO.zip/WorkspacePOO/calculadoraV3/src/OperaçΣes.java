
public class Opera��es {

	public double calculaSoma(double num1, double num2) {
		double soma = num1 + num2;
		return soma;
	}

	public double calculaSubtracao(double num1, double num2) {
		double sub = num1 - num2;
		return sub;
	}

	public double calculaMultiplicacao(double num1, double num2) {
		double mult = num1 * num2;
		return mult;
	}

	public double calculaDivisao(double num1, double num2) {
		double divi = num1 / num2;
		return divi;
	}
}
