package modelo;

public class Multiplicação extends Operações {

	public double calcula() {
		double mult = num1 * num2;
		return mult;
	}
}
