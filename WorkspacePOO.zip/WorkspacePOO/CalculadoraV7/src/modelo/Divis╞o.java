package modelo;

public class Divisão extends Operações {

	public double calcula() {
		double divi = num1 / num2;
		return divi;
	}
}
