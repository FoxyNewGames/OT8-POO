package controle;

import javax.swing.JOptionPane;
import modelo.Divisão;
import modelo.Multiplicação;
import modelo.Operações;
import modelo.Soma;
import modelo.Subtração;
import visualizacao.EntradaSaída;

public class Controladora {

	public void exibeMenu() {
		int continuar;
		double resultado = 0;
		Operações oper = null;

		do {
			double num1 = EntradaSaída.solicitaNumero("1º");
			double num2 = EntradaSaída.solicitaNumero("2º");
			int operacao = EntradaSaída.solicitaOperacao();

			switch (operacao) {
			case 1:
				oper = new Soma();
				break;
			case 2:
				oper = new Subtração();
				break;
			case 3:
				oper = new Multiplicação();
				break;
			case 4:
				while (num2 == 0) {
					num2 = EntradaSaída.solicitaNumero("2º");
				}
				oper = new Divisão();
				break;
			default:
				JOptionPane.showMessageDialog(null, "Operação invalida! A calculadora ser encerrada!");
				System.exit(0);
			}
			oper.setNum1(num1);
			oper.setNum2(num2);
			resultado = oper.calcula();
			EntradaSaída.mostraResultado(resultado, operacao);
			continuar = Integer.parseInt(JOptionPane.showInputDialog("Deseja continuar calculando? 1-Sim | 2-Não"));

		} while (continuar == 1);
	}
}
