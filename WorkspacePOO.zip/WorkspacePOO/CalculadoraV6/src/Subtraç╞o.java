public class Subtração extends Operações {

	public double calcula() {
		double sub = num1 - num2;
		return sub;
	}
}
