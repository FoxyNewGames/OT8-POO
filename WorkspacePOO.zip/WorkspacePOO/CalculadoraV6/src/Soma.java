public class Soma extends Operações {

	public double calcula() {
		double soma = num1 + num2;
		return soma;
	}
}
