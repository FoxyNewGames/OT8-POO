import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int continuar;
		double resultado = 0;
		Operações oper = null;
		do {
			double num1 = EntradaSaída.solicitaNumero("1�");
			double num2 = EntradaSaída.solicitaNumero("2�");
			int operacao = EntradaSaída.solicitaOperacao();

			switch (operacao) {
			case 1:
				oper = new Soma();
				break;
			case 2:
				oper = new Subtração();
				break;
			case 3:
				oper = new Multiplicação();
				break;
			case 4:
				while (num2 == 0) {
					num2 = EntradaSaída.solicitaNumero("2�");
				}
				oper = new Divisão();
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opera��o inv�lida! A calculadora ser� encerrada!");
				System.exit(0);
			}
			oper.setNum1(num1);
			oper.setNum2(num2);
			resultado = oper.calcula();
			EntradaSaída.mostraResultado(resultado, operacao);
			continuar = Integer.parseInt(JOptionPane.showInputDialog("Deseja continuar calculando? 1-Sim | 2-N�o"));

		} while (continuar == 1);
	}
}