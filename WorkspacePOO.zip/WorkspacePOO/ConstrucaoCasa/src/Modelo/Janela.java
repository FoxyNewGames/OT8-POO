package Modelo;

public class Janela {

}
